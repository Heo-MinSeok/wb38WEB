//mobile.cotroller.js

exports.GetLogin = (req, res) => {
    console.log("GET : /mobile/login");
    res.sendFile(__dirname + "/mobile/mobile_login.html");
};

exports.GetMain = (req, res) => {
    console.log("GET : /mobile/main/" + req.params.stunum);
    res.sendFile(__dirname + "/mobile/mobile_main.html");
};

exports.GetJoin = (req, res) => {
    console.log("GET : /mobile/join")
    res.sendFile(__dirname + "/mobile/mobile_join.html");
};

exports.GetEditinfo = (req, res) => {
    console.log("GET : /mobile/main/"+req.params.stunum+"/editinfo")
    res.sendFile(__dirname + "/mobile/mobile_editinfo.html");
};

exports.GetCheck = (req, res) => {
    console.log("GET : /mobile/main/"+req.params.stunum+"/check")
    res.sendFile(__dirname + "/mobile/mobile_check.html");
};

exports.GetAllcheck = (req, res) => {
    console.log("GET : /mobile/main/"+req.params.stunum+"/allcheck")
    res.sendFile(__dirname + "/mobile/mobile_allcheck.html");
};

exports.GetFiles = (req, res) => {
    console.log("GET : /mobile/main/"+req.params.stunum+"/files")
    res.sendFile(__dirname + "/mobile/mobile_file.html");
};
