//page.controller.js

exports.GetRoot = (req, res) => {
    // User-Agent 헤더에서 모바일 여부를 확인
    const isMobile = /Mobile/i.test(req.headers['user-agent']);

    // 모바일인 경우 모바일 버전 출력, 그렇지 않으면 PC 버전 출력
    const version = isMobile ? 'Mobile' : 'PC';

    if (version == 'Mobile') {
        res.redirect('/mobile/login');
    }
    else {
        res.redirect('/login');
    }
    console.log("GET: / [" + version + "]");
};

exports.GetLogin = (req, res) => {
    console.log("GET : /login");
    res.sendFile(__dirname + "/pc/login.html");
};

exports.GetMain = (req, res) => {
    console.log("GET : /main/login/" + req.params.stunum);
    res.sendFile(__dirname + "/pc/main.html");
};

exports.GetJoin = (req, res) => {
    console.log("GET : /join")
    res.sendFile(__dirname + "/pc/join.html");
};

exports.GetEditinfo = (req, res) => {
    console.log(`GET : /main/${req.params.stunum}/editinfo"`)
    res.sendFile(__dirname + '/pc/editinfo.html');
};

exports.GetCheck = (req, res) => {
    console.log(`GET: /main/${req.params.stunum}/check`);
    res.sendFile(__dirname + '/pc/check.html');
};

exports.GetAllcheck = (req, res) => {
    console.log("GET : /main/"+req.params.stunum+"/allcheck")
    res.sendFile(__dirname + '/pc/allcheck.html');
};

exports.GetFiles = (req, res) => {
    console.log("GET : /main/"+req.params.stunum+"/files")
    res.sendFile(__dirname + '/pc/file_admin.html');
};