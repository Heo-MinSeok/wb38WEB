//page.js

const express = require('express');

const dbRouter = require('../DB/db.js');
const userRouter = require('../user/user.js');
const filesRouter = require('../files/files.js');
const pageMid = require('./page.controller.js');
const mobileMid = require('./mobile.controller.js');
const router = express.Router();

module.exports = router;

/////////////
// GET 처리 //
/////////////

// PC/모바일 확인 및 리다이렉트
router.get('/', pageMid.GetRoot);

// 로그인 페이지 
router.get('/login', pageMid.GetLogin);
router.get('/mobile/login', mobileMid.GetLogin);

// 메인 페이지
router.get('/main/:stunum', pageMid.GetMain);
router.get('/mobile/main/:stunum', mobileMid.GetMain);

// 가입 페이지
router.get('/join', pageMid.GetJoin);
router.get('/mobile/join', mobileMid.GetJoin);

// 정보수정 페이지
router.get('/main/:stunum/editinfo', pageMid.GetEditinfo);
router.get('/mobile/main/:stunum/editinfo', mobileMid.GetEditinfo);

// 출석 페이지
router.get('/main/:stunum/check',pageMid.GetCheck);
router.get('/mobile/main/:stunum/check', mobileMid.GetCheck);

// 전체출석 페이지
router.get('/main/:stunum/allcheck', pageMid.GetAllcheck);
router.get('/mobile/main/:stunum/allcheck', mobileMid.GetAllcheck);

// 파일 페이지
router.get('/main/:stunum/files', pageMid.GetFiles);
router.get('/mobile/main/:stunum/files', mobileMid.GetFiles);


//////////////
// POST 처리 //
//////////////

// 가입
router.post('/insert', userRouter) 

// 로그인
router.post('/login', userRouter)

// 조회 및 수정
router.post('/main/:stunum/mypage', userRouter)
router.post('/mobile/main/:stunum/mypage', userRouter) 

router.post('/main/:stunum/mypage/update', userRouter)
router.post('/mobile/main/:stunum/mypage/update', userRouter)

router.post('/attendanceall', userRouter) 
router.post('/main/:stunum/check', userRouter)
router.post('/mobile/main/:stunum/check', userRouter)

// 파일
router.post('/fileupload', filesRouter.UploadFile);
router.post('/filelist', filesRouter.GetFileList);
router.post('/filedelete', filesRouter.DeleteFile);
