        rows[0].faceimg = dataUri;
