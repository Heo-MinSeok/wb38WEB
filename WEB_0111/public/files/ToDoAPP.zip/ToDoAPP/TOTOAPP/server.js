// 서버 실행 -> nodemon server.js

const http = require('http')
const express = require('express'), bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
var cors = require('cors')


const mariadb = require('mariadb')
const pool = mariadb.createPool({
    host: '10.101.169.86',
    database: 'wb38',
    user: 'root',
    password: '1234',
    dateStrings: 'date',
    connectionLimit: 10
});

const app = express()
const port = 5500

app.use(cors(), bodyParser.urlencoded({ extended: false, limit: '10mb' }), bodyParser.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, '/cssfile')));

//----------------
//      요청 처리
//-----------------

http.createServer(app).listen(port, () => {
    console.log(`Express Server started ${port}`)
})

app.get('/', function (요청, 응답) {
    console.log("GET: /");
    응답.sendFile(__dirname + '/login.html');
})
app.get('/login/main/:stunum', function (요청, 응답) {
    console.log(`GET: /login/main/${요청.params.stunum}`);
    응답.sendFile(__dirname + '/index.html');
})
app.get('/join', function (요청, 응답) {
    console.log("GET: /join");
    응답.sendFile(__dirname + '/join.html');
})
app.get('/login/main/:stunum/mypage', function (요청, 응답) {
    console.log(`GET: /login/main/${요청.params.stunum}/mypage`);
    응답.sendFile(__dirname + '/editinfo.html');
})

app.get('/login/main/:stunum/check', function (요청, 응답) {
    console.log(`GET: /login/main/${요청.params.stunum}/check`);
    응답.sendFile(__dirname + '/attendance.html');
})

app.get('/login/main/:stunum/allcheck', function (요청, 응답) {
    console.log(`GET: /login/main/${요청.params.stunum}/attendanceall`);
    응답.sendFile(__dirname + '/attendanceall.html');
})

app.post('/insert', async (req, res) => 
{
    const { stunum, pw, name, gender, faceimg } = req.body;

    try {
        const connection = await pool.getConnection();
        const result = await connection.query('INSERT INTO user (stunum, pw, name, gender, faceimg) VALUES (?,?,?,?,?)', [stunum, pw, name, gender, faceimg]);
        connection.release();

        res.json({ success: true, message: '회원가입이 완료되었습니다.' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: '서버 오류가 발생했습니다.' });
    }
});

app.post('/login', async function (요청, 응답) {
    console.log("POST : Login");
    const conn = await pool.getConnection();
    try {
        const { id, pw } = 요청.body;

        console.log("쿼리작업중...");
        const rows = await conn.query(
            `SELECT pw FROM USER WHERE stunum=${id};`
        );

        if (rows[0].pw == pw) {
            응답.json({ success: true, message: '로그인 성공.' });
        }
        else {
            응답.json({ success: false, message: '로그인 실패.' });
        }
    }
    catch (error) {
        console.error(error);
        응답.status(500).json({ success: false, message: '서버 오류가 발생했습니다.' });
    }
    finally { conn.release(); }
})

app.post('/login/main/:stunum/mypage', async function (요청, 응답) {
    console.log("POST : Login");
    try {
        const stunum = 요청.params.stunum;
        const conn = await pool.getConnection();
        console.log("쿼리작업중...");
        const rows = await conn.query(
            `SELECT * FROM USER  WHERE stunum=${stunum};`
        );

        // 주어진 이미지 데이터 (Buffer 형태로 가정)
        const imageBuffer = Buffer.from(rows[0].faceimg); // 데이터의 배열
        //URI로 변환
        const dataUri = `${imageBuffer}`;

        rows[0].faceimg = dataUri;
        console.log(rows);
        conn.release();

        const jsonS = JSON.stringify(rows);
        응답.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        응답.end(jsonS);
    }
    catch (e) { console.log(e); }

})

// Update Post 요청 처리
app.post('/login/main/:stunum/mypage/update', async (req, res) => {
    const { stunum, pw, newpw, name, gender, birthday, faceimg } = req.body;

    try {
        if (stunum != null && pw != null && name != null && gender != null && newpw != null && faceimg != null) {
            const connection = await pool.getConnection();
            const result = await connection.query(
                `UPDATE user SET pw = ${newpw}, name = '${name}', gender = '${gender}', birthday = '${birthday}', faceimg = '${faceimg}' WHERE stunum = ${stunum} and pw='${pw}'`);
            connection.release();

            console.log(result);
            res.json({ success: true, message: '수정 완료되었습니다.' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: '서버 오류가 발생했습니다.' });
    }
});

app.post('/login/main/:stunum/check', async (req, res) => {
    try 
    { 
        const stunum = req.params.stunum;
        const connection = await pool.getConnection();
        const result = await connection.query(`SELECT * FROM USER_check  WHERE stunum=${stunum};`);
        connection.release();
        console.log(result);
        const jsonS = JSON.stringify(result);
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(jsonS);
    } 
    catch (error) 
    {
        console.error(error);
        res.status(500).json({ success: false, message: '서버 오류가 발생했습니다.' });
    }
});

app.get('/test', async (요청, 응답) => {
    let conn;
    try {
        console.log("DB연결시작");
        conn = await pool.getConnection();
        console.log("쿼리작업중...");
        
        const rows = await conn.query(
            `SELECT * from my_join;`
        );
        console.log(rows);
        const jsonS = JSON.stringify(rows);
        응답.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        응답.end(jsonS);
    }
    catch (e) { console.log(e); }

})

app.get('/test1', function (req, res) { 

    res.sendFile(__dirname+'/cssfile/3D.html');
})